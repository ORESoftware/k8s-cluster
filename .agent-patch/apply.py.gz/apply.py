#!/usr/bin/env python3
from pathlib import Path
import base64

ROOT = Path.cwd()
PAYLOADS = {
  "remote/deployments/benefactor-orchestrator/persistence-contract.test.mjs": "aW1wb3J0IGFzc2VydCBmcm9tICdub2RlOmFzc2VydC9zdHJpY3QnOwppbXBvcnQgeyByZWFkRmlsZSB9IGZyb20gJ25vZGU6ZnMvcHJvbWlzZXMnOwppbXBvcnQgdGVzdCBmcm9tICdub2RlOnRlc3QnOwoKY29uc3Qgc291cmNlID0gYXdhaXQgcmVhZEZpbGUobmV3IFVSTCgnLi9vcmNoZXN0cmF0ZS5tanMnLCBpbXBvcnQubWV0YS51cmwpLCAndXRmOCcpOwoKdGVzdCgncGVyc2lzdHMgdGhlIGZpcnN0IHZlcmlmaWVkIGJ1c2luZXNzIHBob25lIHdpdGhvdXQgb3ZlcndyaXRpbmcgYW4gZXhpc3RpbmcgcGhvbmUnLCAoKSA9PiB7CiAgYXNzZXJ0Lm1hdGNoKHNvdXJjZSwgL1VQREFURSBiZW5lZmFjdG9yXC5iZW5lZmFjdG9yX2xlYWRzLyk7CiAgYXNzZXJ0Lm1hdGNoKHNvdXJjZSwgL3ByaW1hcnlfcGhvbmVccyo9XHMqQ0FTRS9pKTsKICBhc3NlcnQubWF0Y2goc291cmNlLCAvQ09BTEVTQ0VcKEJUUklNXChwcmltYXJ5X3Bob25lXCksICcnXCkgPSAnJy9pKTsKICBhc3NlcnQubWF0Y2goc291cmNlLCAvcmVjb3JkXC5waG9uZXNcWzBcXS8pOwp9KTsKCnRlc3QoJ2tlZXBzIGRpc2NvdmVyeSBzZXBhcmF0ZSBmcm9tIG91dGJvdW5kIG1lc3NhZ2luZycsICgpID0+IHsKICBhc3NlcnQuZG9lc05vdE1hdGNoKHNvdXJjZSwgL2FwaVwuc2VuZGdyaWRcLmNvbVwvdjNcL21haWxcL3NlbmQvaSk7CiAgYXNzZXJ0LmRvZXNOb3RNYXRjaChzb3VyY2UsIC9nbWFpbFwuZ29vZ2xlYXBpc1wuY29tXC9nbWFpbFwvdjFcL3VzZXJzXC8uK1wvbWVzc2FnZXNcL3NlbmQvaSk7Cn0pOwoKdGVzdCgna2VlcHMgYXJiaXRyYXJ5IHBhZ2UgcmV0cmlldmFsIGJlaGluZCB0aGUgcHJpdmF0ZSBzY3JhcGVyJywgKCkgPT4gewogIGFzc2VydC5tYXRjaChzb3VyY2UsIC9kZC13ZWItc2NyYXBlclwuZGVmYXVsdFwuc3ZjXC5jbHVzdGVyXC5sb2NhbC8pOwogIGFzc2VydC5tYXRjaChzb3VyY2UsIC9BTExPV19ESVJFQ1RfRkFMTEJBQ0sgaXMgbm8gbG9uZ2VyIHN1cHBvcnRlZC8pOwp9KTsK",
  "remote/deployments/benefactor-orchestrator/docs/contact-growth-runbook.md": "IyBCZW5lZmFjdG9yIDIwMOKAkzMwMCBwdWJsaWMtYnVzaW5lc3MtY29udGFjdCBkaXNjb3ZlcnkgcnVuYm9vawoKVGhlIG9yY2hlc3RyYXRvciB1c2VzIEJlbmVmYWN0b3IgSUNQIHF1ZXJ5IHJvd3MgZnJvbSBBV1MgUkRTLCBCcmF2ZSBTZWFyY2ggYW5kL29yIFNlcnBlciwgYW5kIHRoZQpwcml2YXRlIGluLWNsdXN0ZXIgYGRkLXdlYi1zY3JhcGVyYCBicm93c2VyIHNlcnZpY2UuIEl0IGV4dHJhY3RzIHB1YmxpYyByb2xlIGluYm94ZXMgYW5kIGJvdW5kZWQgcGhvbmUKY2FuZGlkYXRlcywgc3RvcmVzIHByb3ZlbmFuY2UtYXdhcmUgbGVhZHMsIGFuZCBuZXZlciBzZW5kcyBvdXRib3VuZCBtZXNzYWdlcy4KCiMjIFByZWZsaWdodAoKMS4gQ29uZmlybSBhY3RpdmUgSUNQIGFuZCBxdWVyeSByb3dzIGluIGBiZW5lZmFjdG9yLmJlbmVmYWN0b3Jfc2NyYXBlX3F1ZXJpZXNgIGZvciB0aGUgdGFyZ2V0IGNhdGVnb3J5LgoyLiBDb25maXJtIHRoZSBSRFMgVExTIENBLCBwcml2YXRlIHNjcmFwZXIgYXV0aGVudGljYXRpb24sIGFuZCBhdCBsZWFzdCBvbmUgc2VhcmNoIHByb3ZpZGVyIGNyZWRlbnRpYWwuCjMuIENvbmZpcm0gYGRkLXdlYi1zY3JhcGVyLmRlZmF1bHQuc3ZjLmNsdXN0ZXIubG9jYWxgIGlzIGhlYWx0aHkgYW5kIHRoYXQgaXRzIFBsYXl3cmlnaHQgZXNjYWxhdGlvbiwKICAgcm9ib3RzIGVuZm9yY2VtZW50LCBETlMvcmViaW5kaW5nIHByb3RlY3Rpb24sIGFuZCBwcml2YXRlLW5ldHdvcmsgcmVqZWN0aW9uIGFyZSBlbmFibGVkLgo0LiBTdGFydCB3aXRoIGBQSVBFTElORV9EUllfUlVOPXRydWVgOyByZXZpZXcgcHJvdmlkZXIgY291bnRzLCBxdWVyeSBleGhhdXN0aW9uLCBleGNsdXNpb25zLCBhbmQgdGhlCiAgIHJlZGFjdGVkIGRpZ2VzdCBiZWZvcmUgcGVyc2lzdGVuY2UuCgojIyBCb3VuZGVkIGRyeSBydW4KCmBgYGJhc2gKUElQRUxJTkVfRFJZX1JVTj10cnVlIFwKSUNQX0NBVEVHT1JZPXJvb2ZpbmcgXApUQVJHRVRfRU1BSUxTPTMwMCBcCk1BWF9RVUVSSUVTPTEwMCBcCk1BWF9QQUdFU19QRVJfUVVFUlk9OCBcCkRFQURMSU5FX1NFQ09ORFM9MzYwMCBcClJEU19VUkw9J3Bvc3RncmVzcWw6Ly/igKYnIFwKUEdfU1NMX0NBX0ZJTEU9L3J1bi9zZWNyZXRzL3Jkcy1jYS5wZW0gXApTQ1JBUEVSX0FVVEg9J+KApicgXApTRVJQRVJfQVBJX0tFWT0n4oCmJyBcCkJSQVZFX1NFQVJDSF9BUElfS0VZPSfigKYnIFwKbm9kZSBvcmNoZXN0cmF0ZS5tanMKYGBgCgpVc2Ugb25lIG9yIGJvdGggc2VhcmNoIHByb3ZpZGVycy4gVGhlIHByb3ZpZGVyIGFkYXB0ZXJzIHJlbWFpbiBpc29sYXRlZDsgYSBtaXNzaW5nIGNyZWRlbnRpYWwgZGlzYWJsZXMKb25seSB0aGF0IGFkYXB0ZXIuIERvIG5vdCBlbmFibGUgZGlyZWN0IGFyYml0cmFyeS1kb21haW4gZmFsbGJhY2sgb3IgYXV0b21hdGUgQ0FQVENIQS9hY2Nlc3MtY29udHJvbApieXBhc3MuCgojIyBQZXJzaXN0ZW5jZSBydW4KCkFmdGVyIHRoZSBkcnktcnVuIHJlcG9ydCBpcyByZXZpZXdlZCwgcmVydW4gd2l0aCBgUElQRUxJTkVfRFJZX1JVTj1mYWxzZWAuIFRoZSBvcmNoZXN0cmF0b3I6CgotIGRlZHVwbGljYXRlcyBub3JtYWxpemVkIHJvbGUgZW1haWwgYWRkcmVzc2VzOwotIHNraXBzIHJlY2VudGx5IHNjcmFwZWQvYmxvY2tlZCBkb21haW5zIGFuZCB0aHJvdHRsZWQgaWRlbnRpdGllczsKLSB3cml0ZXMgZWFjaCBsZWFkIGFuZCB0aHJvdHRsZSByZWNvcmQgdHJhbnNhY3Rpb25hbGx5OwotIHN0b3JlcyB0aGUgZmlyc3QgdmVyaWZpZWQgRS4xNjQgYnVzaW5lc3MgcGhvbmUgaW4gYHByaW1hcnlfcGhvbmVgIG9ubHkgd2hlbiB0aGF0IGZpZWxkIGlzIGJsYW5rOwotIHJldGFpbnMgYWxsIHZlcmlmaWVkIHBob25lIGNhbmRpZGF0ZXMgYW5kIGRpc2NvdmVyeSBwcm92ZW5hbmNlIGluIGBtZXRhX2RhdGFgOwotIHByZXNlcnZlcyB1bnN1YnNjcmliZS9kby1ub3QtY29udGFjdCBzdGF0ZTsKLSBlbWl0cyBvbmx5IGhhc2hlZCBjb250YWN0L3NlYXJjaCBpZGVudGlmaWVycyBpbiBsb2dzLgoKVGhlIHRhcmdldCBpcyBhIGRpc2NvdmVyeSBjb3VudCwgbm90IGEgc2VuZCBjb3VudC4gTmV3IGxlYWRzIHN0YXkgaW4gYGxlYWRfc3RhdHVzPSduZXcnYCBhbmQKYG91dHJlYWNoX3N0YXR1cz0ncGVuZGluZydgOyBkaXNjb3ZlcnkgZG9lcyBub3QgY3JlYXRlIGNvbnNlbnQuCgojIyBEb3duc3RyZWFtIGhhbmRvZmYKCjEuIGBiZW5lZmFjdG9yLWF1dG9tYXRpb25zYCBjcmVhdGVzIGEgcHJvdGVjdGVkIDIwMOKAkzMwMC1jb250YWN0IFJEUyByZXZpZXcgc25hcHNob3QuCjIuIEh1bWFuIHJldmlldyBtYXJrcyBDUk0tZWxpZ2libGUgcHVibGljIGJ1c2luZXNzIGNvbnRhY3RzLgozLiBUaGUgYXV0b21hdGlvbnMgc3luYyBpZGVtcG90ZW50bHkgdXBzZXJ0cyByZXZpZXdlZCBpZGVudGl0aWVzIGludG8KICAgYHB1YmxpYy5iZW5lZmFjdG9yX21hcmtldGluZ19jb250YWN0c2Agd2l0aCBgY29uc2VudF9zdGF0dXM9J3Vua25vd24nYCBhbmQgaW50byBIdWJTcG90Lgo0LiBgYmVuZWZhY3Rvci1zZW5kZ3JpZC1vdXRyZWFjaGAgY2FuIHNlZSBvbmx5IGV4cGxpY2l0bHkgb3B0ZWQtaW4gaWRlbnRpdGllcyBhbmQgYWRkaXRpb25hbGx5IHJlcXVpcmVzCiAgIGEgc2lnbmVkIGV4YWN0LXJlY2lwaWVudCBhcHByb3ZhbCBtYW5pZmVzdC4KNS4gVGhlIGZpcnN0IGxpdmUgYmF0Y2ggaXMgY2FwcGVkIGF0IDIwOyBzY2FsZSByZXF1aXJlcyByZXZpZXdlZCBjYW5hcnkgZXZpZGVuY2UuCg=="
}

def replace_once(text, old, new, label):
    count = text.count(old)
    if count != 1:
        raise SystemExit(f"{label}: expected one anchor, found {count}")
    return text.replace(old, new, 1)

def write_payloads():
    for rel, encoded in PAYLOADS.items():
        path = ROOT / rel
        path.parent.mkdir(parents=True, exist_ok=True)
        data = base64.b64decode(encoded)
        if path.exists() and path.read_bytes() != data:
            raise SystemExit(f"refusing to overwrite non-identical additive file: {rel}")
        path.write_bytes(data)

orchestrate = ROOT / 'remote/deployments/benefactor-orchestrator/orchestrate.mjs'
text = orchestrate.read_text()
if 'benefactor-primary-phone-persistence-v1' not in text:
    anchor = "    const leadId = inserted.rows[0]?.id || existing.rows[0]?.id || null;\n"
    addition = anchor + """

    // benefactor-primary-phone-persistence-v1
    // Keep the first verified E.164 business phone, but never overwrite an
    // operator-corrected or previously verified value.
    if (leadId && record.phones[0]) {
      await db.query(
        `UPDATE benefactor.benefactor_leads
            SET primary_phone = CASE
                  WHEN COALESCE(BTRIM(primary_phone), '') = '' THEN $2
                  ELSE primary_phone
                END,
                updated_at = now()
          WHERE id = $1`,
        [leadId, record.phones[0]],
      );
    }
"""
    orchestrate.write_text(replace_once(text, anchor, addition, 'orchestrator phone persistence'))

workflow = ROOT / '.github/workflows/benefactor-orchestrator.yml'
text = workflow.read_text()
if 'persistence-contract.test.mjs' not in text:
    text = replace_once(
        text,
        '          node --check orchestrate.test.mjs\n',
        '          node --check orchestrate.test.mjs\n          node --check persistence-contract.test.mjs\n',
        'workflow syntax lane',
    )
    run_anchor = '        run: node --test orchestrate.test.mjs scraper-contact-bridge.test.mjs provider-diagnostics-bridge.test.mjs\n'
    run_replacement = '        run: node --test orchestrate.test.mjs scraper-contact-bridge.test.mjs provider-diagnostics-bridge.test.mjs persistence-contract.test.mjs\n'
    text = replace_once(text, run_anchor, run_replacement, 'workflow test lane')
    workflow.write_text(text)

write_payloads()
